//
//  Metric.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import Foundation

protocol Metric {
    var id: UUID { get }
    var workoutType: WorkoutType? { get }
    var date: Date? { get }
    var type: Measure { get }
    var value: Double { get }
}
