//
//  Step.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import Foundation

struct Step: Metric, Hashable {
    let id: UUID
    let workoutType: WorkoutType?
    let date: Date?
    let type: Measure = .step
    let count: Int

    var value: Double {
        Double(count)
    }
}
