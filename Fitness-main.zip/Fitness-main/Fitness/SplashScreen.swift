//
//  SplashScreen.swift
//  Courses
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct SplashScreen: View {
    @State private var isActive = false
    @State var presentSideMenu = false
    private let dataManager: CoreDataManager = .shared
    var body: some View {
        VStack {
            if isActive {
                TabBarView(dataManager: dataManager)// Replace with your main content view
            } else {
                VStack {
                    Image(systemName: "figure.gymnastics")// Replace with your logo or image
                        .resizable()
                        .frame(width: 100, height: 100)
                        
                  
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        withAnimation {
                            isActive = true
                        }
                    }
                }
            }
        }
    }
}



