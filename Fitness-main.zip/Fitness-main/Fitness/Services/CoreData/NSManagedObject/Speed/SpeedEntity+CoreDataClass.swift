//
//  SpeedEntity+CoreDataClass.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//
//

import Foundation
import CoreData

@objc(SpeedEntity)
public class SpeedEntity: NSManagedObject {

}
