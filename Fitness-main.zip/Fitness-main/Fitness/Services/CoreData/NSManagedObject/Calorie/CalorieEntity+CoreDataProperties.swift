//
//  CalorieEntity+CoreDataProperties.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//
//

import Foundation
import CoreData


extension CalorieEntity {
    @NSManaged public var id: UUID
    @NSManaged public var workoutType: Int16
    @NSManaged public var date: Date?
    @NSManaged public var type: Int16
    @NSManaged public var count: Int16
    @NSManaged public var workout: WorkoutEntity
}
