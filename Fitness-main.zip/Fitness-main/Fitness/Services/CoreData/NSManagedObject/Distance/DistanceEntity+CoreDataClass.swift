//
//  DistanceEntity+CoreDataClass.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//
//

import Foundation
import CoreData

@objc(DistanceEntity)
public class DistanceEntity: NSManagedObject {

}
