//
//  FitnessApp.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

@main
struct FitnessApp: App {
    private let dataManager: CoreDataManager = .shared

    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
