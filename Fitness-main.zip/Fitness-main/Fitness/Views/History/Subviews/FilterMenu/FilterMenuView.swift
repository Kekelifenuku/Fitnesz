//
//  FilterMenuView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 1/10/2024.
//

import SwiftUI

struct FilterMenuView: View {
    @Binding var workoutType: FilteredWorkoutType

    var body: some View {
        Menu {
            Section("Filter By Activity") {
                ForEach(FilteredWorkoutType.allCases, id: \.self) { filteredType in
                    Button {
                        workoutType = filteredType
                    } label: {
                        HStack {
                            Text(filteredType.rawValue.capitalized)
                            if self.workoutType == filteredType {
                                Image(systemName: "checkmark")
                                    .foregroundStyle(Color.accentColor)
                            }
                        }
                        .accessibilityLabel("\(filteredType.rawValue.capitalized) filter")
                    }
                }
            }
            Section {
                Button {
                    workoutType = .all // Clear filter option
                } label: {
                    Text("Clear Filter")
                        .foregroundColor(.red)
                }
                .accessibilityLabel("Clear all filters")
            }
        } label: {
            Image(systemName: "line.3.horizontal")
                .font(.title)
                .padding() // Adding some padding
//                .background(Color.white.opacity(0.8)) // Background for styling
//                .cornerRadius(8)
        }
    }
}

#Preview {
    FilterMenuView(workoutType: .constant(.running))
}

enum FilteredWorkoutType: String, CaseIterable {
    case all
    case running
    case walking
    case cycling
}
