//
//  WorkoutMetricsView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutMetricsView: View {
    let workout: Workout?
    let allMetrics: Bool

    var body: some View {
        VStack(spacing: 10) { // Added spacing between metrics
            LabeledContent {
                HStack {
                    Text("Duration")
                    Spacer()
                    Text(durationFormatter(for: workout?.duration) ?? "N/A")
                        .accessibilityLabel("Duration: \(durationFormatter(for: workout?.duration) ?? "unknown duration")") // Accessibility label
                }
            } label: {
                Image(systemName: "timer")
                    .padding(.horizontal, 5)
                    .foregroundStyle(Color.accentColor)
            }
            LabeledContent {
                HStack {
                    Text("Distance")
                    Spacer()
                    Text(distanceFormatter(for: workout?.distance?.measure) ?? "N/A")
                    + Text(" \(workout?.distance?.type.unitOfMeasure ?? "")")
                        .accessibilityLabel("Distance: \(distanceFormatter(for: workout?.distance?.measure) ?? "unknown distance")") // Accessibility label
                }
            } label: {
                Image(systemName: workout?.distance?.type.icon ?? "mappin.and.ellipse")
                    .padding(.horizontal, 1)
                    .foregroundStyle(Color.accentColor)
            }
            if allMetrics {
                LabeledContent {
                    HStack {
                        Text("Average Speed")
                        Spacer()
                        Text(speedFormatter(for: workout?.speed?.measure) ?? "N/A")
                        + Text(" \(workout?.speed?.type.unitOfMeasure ?? "")")
                            .accessibilityLabel("Average Speed: \(speedFormatter(for: workout?.speed?.measure) ?? "unknown speed")") // Accessibility label
                    }
                } label: {
                    Image(systemName: workout?.speed?.type.icon ?? "speedometer")
                        .padding(.horizontal, 5)
                        .foregroundStyle(Color.accentColor)
                }
                if workout?.type != .cycling {
                    LabeledContent {
                        HStack {
                            Text("Steps")
                            Spacer()
                            Text(numberFormatterInteger.string(for: workout?.steps?.count ?? 0) ?? "0")
                                .accessibilityLabel("Steps: \(numberFormatterInteger.string(for: workout?.steps?.count ?? 0) ?? "0 steps")") // Accessibility label
                        }
                    } label: {
                        Image(systemName: workout?.steps?.type.icon ?? "figure.walk")
                            .padding(.horizontal, 5)
                            .foregroundStyle(Color.accentColor)
                    }
                }
                LabeledContent {
                    HStack {
                        Text("Calories")
                        Spacer()
                        Text(numberFormatterInteger.string(for: workout?.calories?.count ?? 0) ?? "0")
                        + Text(" \(workout?.calories?.type.unitOfMeasure ?? "")")
                            .accessibilityLabel("Calories: \(numberFormatterInteger.string(for: workout?.calories?.count ?? 0) ?? "0 calories")") // Accessibility label
                    }
                } label: {
                    Image(systemName: workout?.calories?.type.icon ?? "flame")
                        .padding(.horizontal, 5)
                        .foregroundStyle(Color.accentColor)
                }
            }
        }
        .font(.subheadline)
        .padding(.vertical) // Added vertical padding for better spacing
    }

    private let numberFormatterInteger: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 0
        formatter.minimumFractionDigits = 0
        return formatter
    }()

    private let numberFormatterDecimal: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 1
        formatter.minimumFractionDigits = 1
        return formatter
    }()

    private func durationFormatter(for duration: TimeInterval?) -> String? {
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .abbreviated
        formatter.allowedUnits = [.hour, .minute, .second]
        return formatter.string(from: duration ?? 0)
    }

    private func distanceFormatter(for measure: Measurement<UnitLength>?) -> String? {
        guard let distanceInMeters = measure else { return nil }
        return numberFormatterDecimal.string(for: distanceInMeters.converted(to: UnitLength.kilometers).value)
    }

    private func speedFormatter(for measure: Measurement<UnitSpeed>?) -> String? {
        guard let speedInMetersPerSecond = measure else { return nil }
        return numberFormatterDecimal.string(for: speedInMetersPerSecond.converted(to: .kilometersPerHour).value)
    }
}

#Preview {
    WorkoutMetricsView(
        workout: PersistenceController.getWorkoutForPreview(persistenceController: PersistenceController.previewPersistenceController),
        allMetrics: true)
        .padding(.horizontal)
}
