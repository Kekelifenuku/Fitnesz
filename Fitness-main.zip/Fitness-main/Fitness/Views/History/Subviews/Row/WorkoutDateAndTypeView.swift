//
//  WorkoutDateAndTypeView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutDateAndTypeView: View {
    let workout: Workout?

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text(workout?.date?.formatted(date: .abbreviated, time: .omitted).uppercased() ?? "")
                    .accessibilityLabel("Workout date: \(workout?.date?.formatted(date: .abbreviated, time: .omitted) ?? "Unknown date")")
                Spacer()
                Text(workout?.date?.formatted(date: .omitted, time: .shortened) ?? "")
                    .accessibilityLabel("Workout time: \(workout?.date?.formatted(date: .omitted, time: .shortened) ?? "Unknown time")")
            }
            .font(.title2)
            .fontWeight(.bold)
            .foregroundStyle(Color.accentColor)

            HStack {
                Text(workout?.type?.name ?? "")
                    .padding(5)
                    .font(.caption)
                    .foregroundStyle(.white)
                    .background(Color.accentColor.opacity(0.7))
                    .cornerRadius(8)
                    .accessibilityLabel("Workout type: \(workout?.type?.name ?? "Unknown type")") // Accessibility label
                Spacer()
            }
        }
        .padding(.horizontal) // Added padding for the entire view
    }
}

#Preview {
    WorkoutDateAndTypeView(
        workout: PersistenceController.getWorkoutForPreview(persistenceController: PersistenceController.previewPersistenceController)
    )
    .padding(.horizontal)
}
