//
//  WorkoutRowView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutRowView: View {
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var viewModel: WorkoutHistoryViewModel
    let workout: Workout

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .foregroundStyle(colorScheme == .dark ? .white.opacity(0.3) : .black.opacity(0.7))
            HStack(spacing: 5) {
                VStack(spacing: 5) {
                    WorkoutDateAndTypeView(workout: workout)
                    WorkoutMetricsView(workout: workout, allMetrics: false)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .accessibilityLabel("Navigate to workout details") // Accessibility label
            }
            .padding()
            .font(.title3)
            .foregroundStyle(.white)
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button {
                withAnimation {
                    viewModel.delete(workout)
                }
            } label: {
                Image(systemName: "trash")
                    .accessibilityLabel("Delete workout") // Accessibility label
            }
            .tint(.red)
        }
        .background(
            NavigationLink(destination: WorkoutDetailView(workout: workout), label: {
                EmptyView()
            })
            .opacity(0) // Hide the link, but keep it functional
        )
    }
}

#Preview {
    NavigationStack {
        List {
            WorkoutRowView(
                viewModel: WorkoutHistoryViewModel(dataManager: .preview),
                workout: PersistenceController.getWorkoutForPreview(persistenceController: PersistenceController.previewPersistenceController)
            )
            .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
        }
        .listStyle(.plain)
        .padding()
    }
}
