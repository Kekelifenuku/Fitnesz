//
//  CalendarView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct CalendarView: View {
    let selectedDate: Date
    let weeks: [[Date]]
    @State private var activeTab: Int = 1
    @State private var direction: TimeDirection = .none
    let action: (Date) -> ()
    let update: (TimeDirection) -> ()

    var body: some View {
        TabView(selection: $activeTab) {
            ForEach(0..<weeks.count, id: \.self) { index in
                WeekView(selectedDate: selectedDate,
                         currentWeek: weeks[index]) { day in
                    action(day)
                }
                .frame(maxWidth: .infinity)
                .tag(index)
                .onDisappear {
                    guard direction != .none else { return }
                    update(direction)
                    direction = .none
                    activeTab = 1
                }
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .onChange(of: activeTab) { value in
            if value < activeTab {
                direction = .past
            } else if value > activeTab {
                direction = .future
            }
        }
    }
}

#Preview {
    let calendarManager = CalendarManager()
    return CalendarView(
        selectedDate: calendarManager.selectedDate,
        weeks: calendarManager.weeks) { day in
            // Your action for day selection
        } update: { direction in
            // Your action for updating direction
        }
}
