//
//  DecreaseGoalButtonView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct DecreaseGoalButtonView: View {
    let action: () -> Void
    var width: CGFloat = 50 // Default width
    var height: CGFloat = 50 // Default height

    var body: some View {
        Button(action: {
            withAnimation {
                action()
            }
        }) {
            Image(systemName: "minus")
                .font(.title)
                .fontWeight(.bold)
                .frame(width: width, height: height)
                .padding()
                .background(Color.accentColor)
                .cornerRadius(10)
                .foregroundStyle(Color.white)
        }
        .accessibilityLabel("Decrease Goal")
        .accessibilityHint("Decreases the goal value")
        .buttonStyle(PlainButtonStyle()) // Use plain button style to avoid default styling
    }
}

#Preview {
    DecreaseGoalButtonView() {}
}
