//
//  GoalSetupView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct GoalSetupView: View {
    let measureType: String
    let measureValue: String
    let unitOfMeasure: String
    let increaseAction: () -> Void
    let decreaseAction: () -> Void

    var body: some View {
        VStack(alignment: .leading) {
            Text(measureType)
                .font(.title)
                .fontWeight(.semibold)
                .foregroundStyle(Color.accentColor)
                .padding(.horizontal, 20)
            HStack {
                DecreaseGoalButtonView {
                    decreaseAction()
                }
                .accessibilityLabel("Decrease \(measureType) Goal")
                .accessibilityHint("Decrease the goal for \(measureType) by one unit")
                
                Spacer()
                
                VStack {
                    Text(measureValue)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text(unitOfMeasure)
                        .font(.subheadline)
                        .foregroundStyle(.gray)
                }
                
                Spacer()
                
                IncreaseGoalButtonView {
                    increaseAction()
                }
                .accessibilityLabel("Increase \(measureType) Goal")
                .accessibilityHint("Increase the goal for \(measureType) by one unit")
            }
            .padding(.horizontal, 20)
            .foregroundStyle(.gray)
        }
        .padding(.vertical) // Add vertical padding for better spacing
    }
}

#Preview {
    VStack(spacing: 50) {
        GoalSetupView(
            measureType: "Distance",
            measureValue: "5",
            unitOfMeasure: "km",
            increaseAction: {},
            decreaseAction: {}
        )
        GoalSetupView(
            measureType: "Calories",
            measureValue: "500",
            unitOfMeasure: "kcal",
            increaseAction: {},
            decreaseAction: {}
        )
        GoalSetupView(
            measureType: "Steps",
            measureValue: "10,000",
            unitOfMeasure: "steps",
            increaseAction: {},
            decreaseAction: {}
        )
    }
}
