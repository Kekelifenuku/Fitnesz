//
//  GoalsView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

extension UserDefaults {
    enum Keys: String {
        case distance
        case calories
        case steps
    }
}

struct GoalsView: View {
    @AppStorage(UserDefaults.Keys.distance.rawValue) private var distance: Double = 0
    @AppStorage(UserDefaults.Keys.calories.rawValue) private var calories: Int = 0
    @AppStorage(UserDefaults.Keys.steps.rawValue) private var steps: Int = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: 50) {
                GoalSetupView(
                    measureType: Measure.distance.name,
                    measureValue: getFormattedGoal(for: .distance),
                    unitOfMeasure: Measure.distance.unitOfMeasure,
                    increaseAction: { updateGoal(for: .distance, increment: 0.5) },
                    decreaseAction: { updateGoal(for: .distance, increment: -0.5) }
                )
                GoalSetupView(
                    measureType: Measure.calorie.name,
                    measureValue: getFormattedGoal(for: .calories),
                    unitOfMeasure: Measure.calorie.unitOfMeasure,
                    increaseAction: { updateGoal(for: .calories, increment: 50) },
                    decreaseAction: { updateGoal(for: .calories, increment: -50) }
                )
                GoalSetupView(
                    measureType: Measure.step.name,
                    measureValue: getFormattedGoal(for: .steps),
                    unitOfMeasure: Measure.step.unitOfMeasure,
                    increaseAction: { updateGoal(for: .steps, increment: 500) },
                    decreaseAction: { updateGoal(for: .steps, increment: -500) }
                )
            }
            .padding()
            .padding(.bottom)
            .navigationTitle("Goals")
        }
    }

    private func getFormattedGoal(for measure: UserDefaults.Keys) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = measure == .distance ? 1 : 0
        formatter.minimumFractionDigits = measure == .distance ? 1 : 0
        
        let goalValue: Double
        switch measure {
        case .distance:
            goalValue = distance
        case .calories:
            goalValue = Double(calories)
        case .steps:
            goalValue = Double(steps)
        }
        return formatter.string(for: abs(goalValue)) ?? ""
    }

    private func updateGoal(for measure: UserDefaults.Keys, increment: Double) {
        switch measure {
        case .distance:
            let newValue = distance + increment
            distance = max(newValue, 0) // Ensure it doesn't go below zero
        case .calories:
            let newValue = Double(calories) + increment
            calories = max(Int(newValue), 0) // Ensure it doesn't go below zero
        case .steps:
            let newValue = Double(steps) + increment
            steps = max(Int(newValue), 0) // Ensure it doesn't go below zero
        }
    }
}

#Preview {
    GoalsView()
}
