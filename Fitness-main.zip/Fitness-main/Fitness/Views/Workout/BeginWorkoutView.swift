//
//  BeginWorkoutView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct BeginWorkoutView: View {
    @State private var isRecordingWorkout = false
    @State private var selectedWorkoutType: WorkoutType?
    let dataManager: CoreDataManager
    @State private var textToShow = ""
    @State private var animationStarted = false
    private let fullText = "Let's upgrade your skill!"
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 15) {
                    
                    Text(textToShow)
                        .bold()
                        .foregroundStyle(.black.gradient)
                        .padding(.trailing, 160)
                        .onAppear {
                            if !animationStarted {
                                animateText()
                            }
                        }
                    
                    ForEach(WorkoutType.allCases, id: \.self) { workoutType in
                        WorkoutCardView(workoutType: workoutType) {
                            selectedWorkoutType = workoutType
                        }
                        .fullScreenCover(isPresented: Binding<Bool>(
                            get: { selectedWorkoutType == workoutType },
                            set: { newValue in if !newValue { selectedWorkoutType = nil } }
                        )) {
                            RecordWorkoutView(
                                dataManager: dataManager,
                                workoutType: $selectedWorkoutType
                            )
                        }
                    }
                }
            }
            .padding(.top)
        }
    }
    
    private func animateText() {
        animationStarted = true
        textToShow = ""
        var currentIndex = 0
        
        DispatchQueue.main.async {
            Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
                if currentIndex < fullText.count {
                    let index = fullText.index(fullText.startIndex, offsetBy: currentIndex)
                    textToShow.append(fullText[index])
                    currentIndex += 1
                } else {
                    timer.invalidate()
                }
            }
        }
    }
}

#Preview {
    BeginWorkoutView(dataManager: .preview)
}
