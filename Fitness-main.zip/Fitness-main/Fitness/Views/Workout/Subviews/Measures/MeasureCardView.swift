//
//  MeasureCardView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct MeasureCardView: View {
    let measure: Measure?
    let value: Double?
    let size: CGFloat?
    
    var body: some View {
        VStack {
            Text(measure?.name ?? "Measure")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            Text(formattedValue() ?? "--")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.black)
            
            Text(measure?.unitOfMeasure ?? "Unit")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .frame(width: size)
        .padding()
        .background(Color.white.opacity(0.85))
        .cornerRadius(10)
        .shadow(radius: 3)
    }

    private let formatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 1
        formatter.minimumFractionDigits = 1
        return formatter
    }()

    private func formattedValue() -> String? {
        guard let value = value else { return nil }
        switch measure {
        case .distance:
            return formatter.string(for: (value / 1000)) // Convert meters to kilometers
        case .speed:
            return formatter.string(for: (value * 3.6)) // Convert m/s to km/h
        default:
            return formatter.string(for: value)
        }
    }
}

#Preview {
    GeometryReader { geometry in
        let size = geometry.size.width / 2.5
        VStack {
            HStack {
                Spacer()
                MeasureCardView(measure: .distance, value: 1000, size: size)
                Spacer()
                MeasureCardView(measure: .speed, value: 2.78, size: size)
                Spacer()
            }
        }
    }
    .padding(.vertical)
    .frame(height: 100)
    .background(.black.opacity(0.7))
}
