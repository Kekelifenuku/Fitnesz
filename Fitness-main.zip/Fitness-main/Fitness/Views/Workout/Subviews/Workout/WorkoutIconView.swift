//
//  WorkoutIconView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutIconView: View {
    let icon: String?
    
    var body: some View {
        if let icon = icon, !icon.isEmpty {
            Image(systemName: icon)
                .font(.system(size: 60))
                .padding()
                .foregroundStyle(.white)
                .background(Circle().fill(Color.black.opacity(0.6)))
                .shadow(radius: 10)
                .padding(.bottom, 5)
        } else {
            // Optional placeholder or hidden state
            EmptyView()
        }
    }
}

#Preview {
    ZStack {
        WorkoutIconView(icon: "figure.run")
    }
    .frame(maxWidth: .infinity, maxHeight: .infinity)
    .background(.black)
}
