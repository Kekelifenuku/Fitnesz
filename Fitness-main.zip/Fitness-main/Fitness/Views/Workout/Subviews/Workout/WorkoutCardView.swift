//
//  WorkoutCardView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutCardView: View {
    let workoutType: WorkoutType
    let action: () -> ()
    
    var body: some View {
        Button(action: {
            withAnimation {
                action()
            }
        }) {
            ZStack(alignment: .topLeading) {
                Image(workoutType.banner)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                
                HStack {
                    Text(workoutType.name)
                    Image(systemName: workoutType.icon)
                }
                .padding()
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .background(Color.black.opacity(0.3))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .transition(.opacity) // Smooth appearance for text & icon
            }
            .buttonStyle(PlainButtonStyle()) // Consistent style without default button appearance
            .padding(.horizontal)
            .shadow(radius: 5)
            .accessibilityElement(children: .combine)
            .accessibilityLabel(Text("Workout type: \(workoutType.name)"))
        }
    }
}

#Preview {
    ScrollView {
        WorkoutCardView(workoutType: .running) {}
    }
}
