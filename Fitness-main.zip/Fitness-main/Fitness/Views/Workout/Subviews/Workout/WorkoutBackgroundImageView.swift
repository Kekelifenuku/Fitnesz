//
//  WorkoutBackgroundImageView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct WorkoutBackgroundImageView: View {
    let background: String?
    
    var body: some View {
        ZStack {
            if let background = background, !background.isEmpty {
                Image(background)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
            } else {
                Color.gray.opacity(0.5) // Fallback color
                    .ignoresSafeArea()
            }
            
            Color.black.opacity(0.3) // Overlay for better readability
                .ignoresSafeArea()
        }
    }
}

#Preview {
    WorkoutBackgroundImageView(background: WorkoutType.running.background)
}
