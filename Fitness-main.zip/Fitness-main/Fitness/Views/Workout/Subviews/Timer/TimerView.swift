//
//  TimerView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct TimerView: View {
    @Binding var errorIsThrown: Bool
    @Binding var accessIsDenied: Bool
    let elapsedTime: TimeInterval
    let timerIsNil: Bool
    let timerIsPaused: Bool
    let startAction: () -> ()
    let pauseAction: () -> ()
    let resumeAction: () -> ()
    let stopAction: () -> ()
    
    private var errorMessage: String? {
        if errorIsThrown { return "Location Access Error" }
        if accessIsDenied { return "Access Denied" }
        return nil
    }
    
    var body: some View {
        VStack {
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .font(.title2)
                    .foregroundStyle(.red)
            } else {
                Text(formatTimeIntervalToString(elapsedTime))
                    .font(.largeTitle)
                    .foregroundStyle(.white)
            }
            HStack(spacing: 10) {
                TimerButtonView(
                    label: timerLabel,
                    color: timerColor,
                    disabled: errorMessage != nil,
                    action: timerAction
                )
                if !timerIsNil {
                    TimerButtonView(
                        label: "Stop",
                        color: .red,
                        disabled: false,
                        action: stopAction
                    )
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.black.opacity(0.7))
        .cornerRadius(12)
        .shadow(radius: 5)
    }
    
    private func formatTimeIntervalToString(_ elapsedTime: TimeInterval) -> String {
        Duration(
            secondsComponent: Int64(elapsedTime),
            attosecondsComponent: 0
        ).formatted(.time(pattern: .hourMinuteSecond(padHourToLength: 2)))
    }
    
    // Computed properties for timer button state
    private var timerLabel: String {
        if timerIsNil { return "Start" }
        return timerIsPaused ? "Resume" : "Pause"
    }
    
    private var timerColor: Color {
        if timerIsNil || timerIsPaused { return .green }
        return .yellow
    }
    
    private var timerAction: () -> () {
        if timerIsNil { return startAction }
        return timerIsPaused ? resumeAction : pauseAction
    }
}

#Preview {
    TimerView(
        errorIsThrown: .constant(false),
        accessIsDenied: .constant(false),
        elapsedTime: 5130,
        timerIsNil: false,
        timerIsPaused: false
    ) {
        print("Start")
    } pauseAction: {
        print("Pause")
    } resumeAction: {
        print("Resume")
    } stopAction: {
        print("Stop")
    }
}
