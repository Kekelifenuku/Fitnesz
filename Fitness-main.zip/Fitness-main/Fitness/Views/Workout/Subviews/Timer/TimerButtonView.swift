//
//  TimerButtonView.swift
//  Fitness
//
//  Created by Fenuku kekeli on 8/25/24.
//

import SwiftUI

struct TimerButtonView: View {
    let label: String
    let color: Color
    let disabled: Bool
    let action: () -> ()
    
    var body: some View {
        Button {
            withAnimation {
                action()
            }
        } label: {
            Text(label)
                .frame(maxWidth: .infinity)
                .font(.title2)
                .foregroundColor(disabled ? .white : .black)
                .padding(.vertical, 20)
                .background(disabled ? .gray : color)
                .cornerRadius(10)
                .shadow(color: .black.opacity(0.3), radius: disabled ? 0 : 5)
        }
        .frame(width: 150)
        .padding(.bottom)
        .disabled(disabled)
        .accessibilityLabel(label)
        .scaleEffect(disabled ? 1 : 1.02)
        .animation(.easeInOut(duration: 0.2), value: disabled)
    }
}

#Preview {
    VStack {
        TimerButtonView(label: "Start", color: .green, disabled: false) {
            print("Start action")
        }
        TimerButtonView(label: "Pause", color: .yellow, disabled: true) {
            print("Pause action")
        }
    }
    .padding()
    .background(Color.black)
}

